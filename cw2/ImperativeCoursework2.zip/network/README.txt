Edward Faull-pb19639
Currently:
-Weighted graphs
-Depth first search
-Tree, cyclic, acyclic checks
-Dijkstra's algorithm - distances and paths
-Prints as adjacency list and matrix
-Can be used as API - use #include <network.h> to use in other programs
-Check if one network is a subnet of another
-Tree depth

Future:
-Make matrix neater(if x>9 or weight >= 10)
-Make, insert, searching binary trees
-Cliques (could allow for undirected networks here)
-Tree Traversal (infix, postfix, prefix)